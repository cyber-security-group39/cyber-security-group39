
import os

def check_file_exists(path):
    exists = os.path.exists(path)
    print(f"{'✓' if exists else '✗'} {path}")
    return exists

print("Checking if all required files exist:")
files_to_check = [
    "gui/components/__init__.py",
    "gui/components/output_console.py",
    "gui/components/banner.py",
    "gui/tabs/__init__.py",
    "gui/tabs/port_scanner_tab.py",
    "gui/tabs/device_discovery_tab.py",
    "gui/tabs/web_scanner_tab.py",
    "config/__init__.py",
    "config/theme.py",
    "utils/__init__.py",
    "utils/network_utils.py",
    "utils/validation_utils.py",
    "utils/security_utils.py",
    "scanners/__init__.py",
    "scanners/port_scanner.py",
    "scanners/device_discovery.py",
    "scanners/web_vuln_scanner.py",
    "error_handler.py",
    "process_monitor.py",
    "tor_manager.py",
    "main.py"
]

all_exist = True
for file_path in files_to_check:
    if not check_file_exists(file_path):
        all_exist = False

print(f"\nAll files exist: {all_exist}")
