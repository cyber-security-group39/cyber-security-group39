import socket
import requests
import urllib.parse
import dns.resolver
import ssl
import whois
from datetime import datetime
from error_handler import error_handler
from tor_manager import tor_manager

@error_handler.protect_process
def make_network_request(url, method='GET', **kwargs):
    """
    Make a network request using Tor if enabled, otherwise use direct connection
    """
    if tor_manager.is_tor_enabled:
        session = tor_manager.get_tor_session()
    else:
        session = requests.Session()
        
        if 'timeout' not in kwargs:
            kwargs['timeout'] = 10
    
    return session.request(method, url, **kwargs)

@error_handler.protect_process
def get_ip_address(domain):
    try:
        return socket.gethostbyname(domain)
    except:
        return None

@error_handler.protect_process
def get_domain_from_url(url):
    try:
        return urllib.parse.urlparse(url).netloc
    except:
        return url

@error_handler.protect_process
def get_geoip_info(ip):
    try:
        response = make_network_request(f"http://ip-api.com/json/{ip}")
        data = response.json()
        if data['status'] == 'success':
            return f"{data['city']}, {data['regionName']}, {data['country']} - {data['isp']}"
        return "Unknown"
    except:
        return "Unknown"

@error_handler.protect_process
def get_whois_info(domain):
    try:
        if "://" in domain:
            domain = urllib.parse.urlparse(domain).netloc
        
        domain = domain.replace("www.", "")
        
        w = whois.whois(domain)
        
        info = []
        if w.registrar:
            info.append(f"Registrar: {w.registrar}")
        if w.creation_date:
            if isinstance(w.creation_date, list):
                info.append(f"Created: {w.creation_date[0]}")
            else:
                info.append(f"Created: {w.creation_date}")
        if w.expiration_date:
            if isinstance(w.expiration_date, list):
                info.append(f"Expires: {w.expiration_date[0]}")
            else:
                info.append(f"Expires: {w.expiration_date}")
        
        return " | ".join(info) if info else "No WHOIS information available"
    except Exception as e:
        return f"WHOIS lookup failed: {str(e)}"

@error_handler.protect_process
def get_ssl_cert_info(hostname, port=443):
    try:
        context = ssl.create_default_context()
        with socket.create_connection((hostname, port), timeout=5) as sock:
            with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                cert = ssock.getpeercert()
                
                info = []
                issuer = dict(x[0] for x in cert['issuer'])
                info.append(f"Issuer: {issuer.get('organizationName', 'Unknown')}")
                
                not_before = cert.get('notBefore', '')
                not_after = cert.get('notAfter', '')
                if not_before and not_after:
                    info.append(f"Valid: {not_before} to {not_after}")
                
                if not_after:
                    expire_date = datetime.strptime(not_after, '%b %d %H:%M:%S %Y %Z')
                    days_until_expire = (expire_date - datetime.now()).days
                    info.append(f"Expires in: {days_until_expire} days")
                
                return " | ".join(info)
    except:
        return "SSL certificate information unavailable"
