import ipaddress
import urllib.parse
from error_handler import error_handler

@error_handler.protect_process
def is_valid_ip(ip):
    try:
        ipaddress.ip_address(ip)
        return True
    except ValueError:
        return False

@error_handler.protect_process
def is_valid_ip_range(ip_range):
    try:
        ipaddress.ip_network(ip_range, strict=False)
        return True
    except ValueError:
        return False

@error_handler.protect_process
def is_valid_url(url):
    try:
        result = urllib.parse.urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False

@error_handler.protect_process
def normalize_url(url):
    if not url.startswith("http://") and not url.startswith("https://"):
        return "http://" + url
    return url.rstrip('/')
