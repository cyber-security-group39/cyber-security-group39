import hashlib
import secrets
import string
import re
from error_handler import error_handler

@error_handler.protect_process
def check_password_strength(password):
   
    score = 0
    
    
    if len(password) >= 8:
        score += 25
    if len(password) >= 12:
        score += 15
    if re.search(r'[A-Z]', password):
        score += 15
    if re.search(r'[a-z]', password):
        score += 15
    if re.search(r'[0-9]', password):
        score += 15
    if re.search(r'[^A-Za-z0-9]', password):
        score += 15
    
    return min(score, 100)

@error_handler.protect_process
def generate_random_string(length=16):
    
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))

@error_handler.protect_process
def hash_string(data, algorithm='sha256'):

    hasher = hashlib.new(algorithm)
    hasher.update(data.encode('utf-8'))
    return hasher.hexdigest()
